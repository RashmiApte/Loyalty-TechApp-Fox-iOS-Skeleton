//
//  main.m
//  LoyaltyApp
//
//  Created by Ajeet Sharma on 2/20/14.
//
//

#import <UIKit/UIKit.h>

#import "CAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([CAppDelegate class]));
    }
}
