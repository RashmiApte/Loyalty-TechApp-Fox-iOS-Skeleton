//
//  MyRetailerCell.h
//  LoyaltyApp
//
//  Created by ankit on 2/27/14.
//
//

#import <UIKit/UIKit.h>

@interface MyRetailerCell : UITableViewCell
@property(strong,nonatomic)UIImageView *imgretailerlogo;
@property(strong,nonatomic)UIButton *btnremoveretailer;
@property(strong,nonatomic)UILabel *lblretailername;

@end
