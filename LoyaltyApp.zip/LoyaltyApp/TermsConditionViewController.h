//
//  Terms&ConditionViewController.h
//  LoyaltyApp
//
//  Created by Ajeet Sharma on 2/28/14.
//
//

#import <UIKit/UIKit.h>

@interface TermsConditionViewController : UIViewController
{
    UIButton *btnCheck;
    UIButton *btnPushToSignup;
    UILabel *lblTermsCondition;
    UILabel *lblAccept;
    

}
@end
