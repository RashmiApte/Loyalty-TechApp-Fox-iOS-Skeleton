//
//  LeftPanelcell.h
//  LoyaltyApp
//
//  Created by ankit on 2/27/14.
//
//

#import <UIKit/UIKit.h>

@interface LeftPanelcell : UITableViewCell
@property(strong,nonatomic)UIImageView *imgeleftpanellogo;
@property(strong,nonatomic)UILabel *lblleftpaneltitle;
@property(strong,nonatomic)UIImageView *imgbackgroundimg;



@end
