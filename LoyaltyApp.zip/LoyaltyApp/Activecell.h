//
//  Activecell.h
//  LoyaltyApp
//
//  Created by ankit on 2/28/14.
//
//

#import <UIKit/UIKit.h>

@interface Activecell : UITableViewCell
@property(strong,nonatomic)UILabel *lblActivecampaginname;
@property(strong,nonatomic)UILabel *lblActivecampaginstartdate;
@property(strong,nonatomic)UILabel *lblActivecampaginenddate;
@property(strong,nonatomic)UIImageView *imgactivecampagin;
@property(strong,nonatomic)UIImageView *imgArrow;




@end
