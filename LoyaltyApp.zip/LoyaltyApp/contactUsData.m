//
//  contactUsData.m
//  YesPayCardHolderWallet
//
//  Created by Nirmal Patidar on 28/07/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "contactUsData.h"


@implementation contactUsData
@synthesize email1;
@synthesize email2;
@synthesize email3;
@synthesize phone1;
@synthesize phone2;
@synthesize phone3;
@synthesize country;
@synthesize message;


@end
